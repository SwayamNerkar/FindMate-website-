import React, { useState } from 'react';
import { Search, MapPin, Code } from 'lucide-react';
import type { SearchFilters } from '../types';

interface GithubSearchProps {
  onSearch: (filters: SearchFilters) => void;
  isLoading: boolean;
}

export function GithubSearch({ onSearch, isLoading }: GithubSearchProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    username: '',
    location: '',
    language: '',
    technologies: {
      nextjs: false,
      flutter: false,
      react: false
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedFilters = {
      ...filters,
      username: filters.username?.trim(),
      location: filters.location?.trim(),
      language: filters.language?.trim()
    };
    
    if (trimmedFilters.username || trimmedFilters.location || trimmedFilters.language || 
        trimmedFilters.technologies?.nextjs || trimmedFilters.technologies?.flutter || 
        trimmedFilters.technologies?.react) {
      onSearch(trimmedFilters);
    }
  };

  const handleTechnologyChange = (tech: keyof typeof filters.technologies) => {
    setFilters(prev => ({
      ...prev,
      technologies: {
        ...prev.technologies,
        [tech]: !prev.technologies?.[tech]
      }
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
            <Search size={18} className="text-black" />
          </div>
          <input
            type="text"
            value={filters.username}
            onChange={(e) => setFilters(prev => ({ ...prev, username: e.target.value }))}
            placeholder="GitHub username"
            className="neo-brutalism-input w-full pl-10 pr-4 py-3 text-black font-medium placeholder:text-gray-500"
            disabled={isLoading}
          />
        </div>

        <div className="relative">
          <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
            <MapPin size={18} className="text-black" />
          </div>
          <input
            type="text"
            value={filters.location}
            onChange={(e) => setFilters(prev => ({ ...prev, location: e.target.value }))}
            placeholder="Location"
            className="neo-brutalism-input w-full pl-10 pr-4 py-3 text-black font-medium placeholder:text-gray-500"
            disabled={isLoading}
          />
        </div>

        <div className="relative">
          <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
            <Code size={18} className="text-black" />
          </div>
          <input
            type="text"
            value={filters.language}
            onChange={(e) => setFilters(prev => ({ ...prev, language: e.target.value }))}
            placeholder="Programming language"
            className="neo-brutalism-input w-full pl-10 pr-4 py-3 text-black font-medium placeholder:text-gray-500"
            disabled={isLoading}
          />
        </div>
      </div>

      <div className="flex flex-wrap justify-center gap-4">
        <label className="neo-brutalism-card px-4 py-2 cursor-pointer flex items-center gap-2">
          <input
            type="checkbox"
            checked={filters.technologies?.nextjs}
            onChange={() => handleTechnologyChange('nextjs')}
            className="w-4 h-4 accent-yellow-400"
            disabled={isLoading}
          />
          <span className="font-bold text-black">Next.js</span>
        </label>
        <label className="neo-brutalism-card px-4 py-2 cursor-pointer flex items-center gap-2">
          <input
            type="checkbox"
            checked={filters.technologies?.flutter}
            onChange={() => handleTechnologyChange('flutter')}
            className="w-4 h-4 accent-yellow-400"
            disabled={isLoading}
          />
          <span className="font-bold text-black">Flutter</span>
        </label>
        <label className="neo-brutalism-card px-4 py-2 cursor-pointer flex items-center gap-2">
          <input
            type="checkbox"
            checked={filters.technologies?.react}
            onChange={() => handleTechnologyChange('react')}
            className="w-4 h-4 accent-yellow-400"
            disabled={isLoading}
          />
          <span className="font-bold text-black">React</span>
        </label>
      </div>

      <div className="flex justify-center">
        <button
          type="submit"
          disabled={isLoading}
          className="neo-brutalism-button px-8 py-3 text-black text-lg disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Searching...' : 'Search'}
        </button>
      </div>
    </form>
  );
}
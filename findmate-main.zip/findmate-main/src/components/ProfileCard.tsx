import React from 'react';
import { ExternalLink, Github, MapPin } from 'lucide-react';
import type { Profile } from '../types';

interface ProfileCardProps {
  profile: Profile;
  onConnect?: () => void;
}

export function ProfileCard({ profile, onConnect }: ProfileCardProps) {
  return (
    <div className="neo-brutalism-card p-6">
      <div className="flex items-center space-x-4">
        <img
          src={profile.avatar}
          alt={profile.name}
          className="w-16 h-16 rounded-full border-4 border-black"
        />
        <div>
          <h3 className="text-2xl font-black text-black">{profile.name}</h3>
          <a
            href={profile.githubUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-black hover:text-gray-700 flex items-center gap-1 font-bold"
          >
            <Github size={16} />
            View GitHub Profile
            <ExternalLink size={14} />
          </a>
        </div>
      </div>
      
      <p className="mt-4 text-black font-medium">{profile.bio}</p>

      {profile.location && (
        <div className="mt-4 flex items-center text-black font-bold">
          <MapPin size={16} className="mr-2" />
          {profile.location}
        </div>
      )}
      
      <div className="mt-4">
        <h4 className="font-black text-black mb-2">Top Languages:</h4>
        <div className="flex flex-wrap gap-2">
          {profile.languages.map((lang) => (
            <span
              key={lang}
              className="neo-brutalism-tag px-3 py-1 text-black"
            >
              {lang}
            </span>
          ))}
        </div>
      </div>
      
      {onConnect && (
        <button
          onClick={onConnect}
          className="neo-brutalism-button mt-6 w-full py-3 px-4 text-black"
        >
          Connect
        </button>
      )}
    </div>
  );
}
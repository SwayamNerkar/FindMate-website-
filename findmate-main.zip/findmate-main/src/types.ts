export interface Profile {
  id: string;
  name: string;
  avatar: string;
  bio: string;
  languages: string[];
  githubUrl: string;
  location: string;
}

export interface GithubProfile {
  login: string;
  name: string;
  avatar_url: string;
  bio: string;
  html_url: string;
  location: string;
}

export interface SearchFilters {
  username?: string;
  location?: string;
  language?: string;
  technologies?: {
    nextjs?: boolean;
    flutter?: boolean;
    react?: boolean;
  };
}
import React, { useState } from 'react';
import { Octokit } from 'octokit';
import { Users, Github } from 'lucide-react';
import { GithubSearch } from './components/GithubSearch';
import { ProfileCard } from './components/ProfileCard';
import type { Profile, GithubProfile, SearchFilters } from './types';

// Initialize Octokit with authentication
const octokit = new Octokit({
  auth: import.meta.env.VITE_GITHUB_TOKEN,
  request: {
    retries: 3,
    retryAfter: 5
  }
});

async function searchGithubUsers(filters: SearchFilters): Promise<Profile[]> {
  try {
    let query = '';
    if (filters.username) query += filters.username;
    if (filters.location) query += ` location:${filters.location}`;
    if (filters.language) query += ` language:${filters.language}`;
    
    // Add technology-specific queries
    if (filters.technologies?.nextjs) query += ' next.js OR nextjs';
    if (filters.technologies?.flutter) query += ' flutter';
    if (filters.technologies?.react) query += ' react';
    
    const searchResponse = await octokit.request('GET /search/users', {
      q: query.trim(),
      per_page: 5,
      headers: {
        'X-GitHub-Api-Version': '2022-11-28'
      }
    });

    const profiles = await Promise.all(
      searchResponse.data.items.map(async (user) => {
        try {
          const userResponse = await octokit.request('GET /users/{username}', {
            username: user.login,
            headers: {
              'X-GitHub-Api-Version': '2022-11-28'
            }
          });

          const languagesResponse = await octokit.request('GET /users/{username}/repos', {
            username: user.login,
            sort: 'updated',
            per_page: 10,
            headers: {
              'X-GitHub-Api-Version': '2022-11-28'
            }
          });

          const userData = userResponse.data as GithubProfile;
          
          const languages = Array.from(new Set(
            languagesResponse.data
              .map(repo => repo.language)
              .filter(Boolean)
          ));

          return {
            id: userData.login,
            name: userData.name || userData.login,
            avatar: userData.avatar_url,
            bio: userData.bio || 'No bio available',
            languages: languages as string[],
            githubUrl: userData.html_url,
            location: userData.location || 'Location not specified'
          };
        } catch (error: any) {
          if (error.status === 403) {
            console.warn(`Rate limit hit for user ${user.login}`);
            return null;
          }
          throw error;
        }
      })
    );

    // Filter out any null results from rate limit hits
    return profiles.filter((profile): profile is Profile => profile !== null);
  } catch (error: any) {
    if (error.status === 403) {
      console.error('Rate limit exceeded. Please try again later.');
      throw new Error('Rate limit exceeded. Please try again later.');
    }
    console.error('Error searching GitHub profiles:', error);
    return [];
  }
}

function App() {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async (filters: SearchFilters) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const results = await searchGithubUsers(filters);
      
      if (results.length > 0) {
        setProfiles(results);
      } else {
        setError('No matching profiles found. Try adjusting your search criteria.');
        setProfiles([]);
      }
    } catch (error: any) {
      setError(error.message || 'An error occurred while searching. Please try again later.');
      setProfiles([]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FFE5E5]">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Users size={40} className="text-black" />
            <Github size={40} className="text-black" />
          </div>
          <h1 className="text-5xl font-black text-black mb-4">
            Hackathon Teammate Finder
          </h1>
          <p className="text-black text-xl font-medium">
            Find the perfect teammate based on location, programming languages, and GitHub profiles
          </p>
        </div>

        <div className="flex justify-center mb-8">
          <GithubSearch onSearch={handleSearch} isLoading={isLoading} />
        </div>

        {isLoading && (
          <div className="text-center text-black font-bold text-xl">
            Searching for profiles...
          </div>
        )}

        {error && (
          <div className="text-center text-red-600 mb-8 font-bold text-xl">
            {error}
          </div>
        )}

        {profiles.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {profiles.map(profile => (
              <ProfileCard
                key={profile.id}
                profile={profile}
                onConnect={() => alert('Connection feature coming soon!')}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;